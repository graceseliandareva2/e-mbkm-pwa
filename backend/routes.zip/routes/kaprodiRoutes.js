const express = require('express');
const router = express.Router();
const { verifyToken, authorizeRoles } = require('../middleware/authMiddleware');
const {
  getPeriode, tambahPeriode, updatePeriode, toggleForm,
  assignDosen,
  getVerifikasiPengajuan,
  verifikasiPengajuan, hapusPengajuan, verifikasiDokumen, getMonitoringDokumen, getDetailMonitoring,
  getDashboardStats,
  getPengajuanDisetujui,
  getRekapNilai,
} = require('../controllers/kaprodiController');
// PERUBAHAN (item #6): getDaftarMahasiswa & getDaftarDosen sudah pindah ke
// staffController.js (satu sumber data). Kaprodi tetap butuh baca daftar ini
// buat assignDosen, jadi di-import langsung dari staffController -- bukan
// diduplikasi query-nya di sini.
const {
  getDaftarMahasiswa, getDaftarDosen,
} = require('../controllers/staffController');

const auth = [verifyToken, authorizeRoles('kaprodi')];

router.get('/dashboard-stats', auth, getDashboardStats);

router.get('/periode', auth, getPeriode);
router.post('/periode', auth, tambahPeriode);
router.put('/periode/:id', auth, updatePeriode);
router.patch('/periode/:id/toggle-form', auth, toggleForm);

// PERUBAHAN (item #6): import-mahasiswa, import-dosen, dan seluruh CRUD
// tulis mahasiswa/dosen (POST/PUT/DELETE/reset-password) sudah pindah ke
// staffRoutes.js. Di sini cuma disisakan GET buat kebutuhan assignDosen.

router.get('/mahasiswa', auth, getDaftarMahasiswa);

router.get('/pengajuan-disetujui', auth, getPengajuanDisetujui);
router.get('/rekap-nilai', auth, getRekapNilai);

router.get('/verifikasi-pengajuan', auth, getVerifikasiPengajuan);

router.get('/dosen', auth, getDaftarDosen);

router.get('/monitoring', auth, getMonitoringDokumen);
router.get('/monitoring/:pengajuan_id', auth, getDetailMonitoring);
router.post('/assign-dosen', auth, assignDosen);
router.patch('/pengajuan/:id/verifikasi', auth, verifikasiPengajuan);
router.patch('/dokumen/:id/verifikasi', auth, verifikasiDokumen);
router.delete('/pengajuan/:id', auth, hapusPengajuan);

module.exports = router;