const { v4: uuidv4 } = require("uuid");
const db = require("../config/db");
const ExcelJS = require("exceljs");
const PDFDocument = require("pdfkit");
const bcrypt = require("bcryptjs");
const xlsx = require("xlsx");
const fs = require("fs");

// =========================================================
// MANAJEMEN MAHASISWA & DOSEN (CRUD) -- dipindah dari kaprodiController.js
// (item #6 di daftar next-steps). Kaprodi tetap butuh baca data mahasiswa
// & dosen (buat assignDosen), jadi endpoint GET di bawah ini (getDaftarMahasiswa
// & getDaftarDosen) dipanggil bareng oleh staff DAN kaprodi -- satu sumber data,
// bukan duplikat query. Sesuaikan middleware role di route-nya supaya kedua role
// bisa GET, tapi cuma staff yang boleh import/tambah/update/hapus/reset password.
// =========================================================

// ========== IMPORT MAHASISWA ==========
// PERUBAHAN: insert ke `users` sekarang HANYA (id, username, password, role) —
// nama & email TIDAK lagi disimpan di `users`, cuma di tabel `mahasiswa`.

const importMahasiswa = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        message: "File tidak ditemukan.",
      });
    }

    const workbook = xlsx.readFile(req.file.path);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_json(sheet);

    if (data.length === 0) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({
        message: "File kosong atau format tidak sesuai.",
      });
    }

    let berhasil = 0;
    let gagal = 0;
    let errors = [];

    for (const row of data) {
      try {
        const nim = String(
          row["NIM Mahasiswa"] ||
          row["NIM"] ||
          row["nim"] ||
          ""
        ).trim();

        const nama = String(
          row["Nama Mahasiswa"] ||
          row["Nama"] ||
          row["nama"] ||
          ""
        ).trim();

        const email = String(
          row["Email Mahasiswa"] ||
          row["E-mail Mahasiswa"] ||
          row["E-Mail Mahasiswa"] ||
          row["Email"] ||
          row["email"] ||
          ""
        ).trim();

        const prodi = String(
          row["Program Studi"] ||
          row["Prodi"] ||
          row["prodi"] ||
          ""
        ).trim();

        if (!nim || !nama) {
          gagal++;
          errors.push("Baris dilewati: NIM atau Nama kosong.");
          continue;
        }

        // ============================
        // Cek apakah NIM sudah ada
        // ============================
        const [existingMahasiswa] = await db.query(
          "SELECT id FROM mahasiswa WHERE nim = ?",
          [nim]
        );

        if (existingMahasiswa.length > 0) {
          gagal++;
          errors.push(`NIM ${nim} sudah terdaftar.`);
          continue;
        }

        // ============================
        // Cek username/email
        // ============================
        const username = email || nim;

        const [existingUser] = await db.query(
          "SELECT id FROM users WHERE username = ?",
          [username]
        );

        if (existingUser.length > 0) {
          gagal++;
          errors.push(`Username ${username} sudah digunakan.`);
          continue;
        }

        // ============================
        // Buat akun user
        // ============================
        const userId = uuidv4();
        const hashedPassword = await bcrypt.hash(nim, 8);

        await db.query(
          `INSERT INTO users
          (id, username, password, role)
          VALUES (?, ?, ?, ?)`,
          [
            userId,
            username,
            hashedPassword,
            "mahasiswa",
          ]
        );

        // ============================
        // Simpan mahasiswa
        // ============================
        await db.query(
          `INSERT INTO mahasiswa
          (
            id,
            user_id,
            nim,
            nama,
            email,
            program_studi
          )
          VALUES (?, ?, ?, ?, ?, ?)`,
          [
            uuidv4(),
            userId,
            nim,
            nama,
            email || null,
            prodi || null,
          ]
        );

        berhasil++;
      } catch (err) {
        gagal++;
        errors.push(err.message);
      }
    }

    fs.unlinkSync(req.file.path);

    return res.json({
      message: `Import selesai. Berhasil: ${berhasil}, Gagal: ${gagal}`,
      berhasil,
      gagal,
      errors,
    });
  } catch (error) {
    console.error("Import mahasiswa error:", error);

    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }

    return res.status(500).json({
      message: "Terjadi kesalahan server.",
    });
  }
};

// ========== TAMBAH MAHASISWA ==========
// FIX:
// 1. `periode_id` sekarang di-destructure dari req.body (sebelumnya dipakai tapi
//    tidak pernah didefinisikan -> ReferenceError setiap kali endpoint ini dipanggil).
// 2. Cek NIM sekarang cuma `WHERE nim = ?` (NIM unik global, tabel mahasiswa
//    sudah tidak scoped per periode) -- pesan error disesuaikan jadi
//    "NIM sudah terdaftar." (sama seperti importMahasiswa), bukan lagi
//    "...di periode ini" yang menyesatkan.
// 3. INSERT ke `mahasiswa` sekarang persis 7 value untuk 7 kolom (sebelumnya
//    8 value dikirim ke 7 kolom -- ada `periode_id` & `null` nyasar di akhir).
//    `imported_by` diisi `req.user.id` (bukan `null` terus).
// 4. Ditambahkan INSERT ke `pengajuan` dengan status='draft' begitu mahasiswa
//    baru dibuat -- sesuai keputusan: baris pengajuan otomatis dibuat saat staff
//    memilih periode di dropdown, nanti mahasiswa sendiri yang submit/lengkapi
//    form pengajuannya. Ini menggantikan konsep lama `mahasiswa.periode_id`.
//
// TERKONFIRMASI (dari users.sql): tabel `users` cuma punya `username` (UNIQUE),
// tidak ada kolom `email` terpisah. Untuk akun mahasiswa/dosen, `username`
// memang diisi emailnya (mis. `23110037@itbss.ac.id`) -- konsisten dipakai
// di importMahasiswa/tambahDosen/dll. Jadi pengecekan "email sudah dipakai
// role lain" lewat `username` di bawah ini sudah benar, bukan lagi asumsi.

const tambahMahasiswa = async (req, res) => {
  try {
    const { nim, nama, email, program_studi, periode_id } = req.body;

    if (!nim || !nama || !email || !program_studi || !periode_id) {
      return res.status(400).json({ message: "Semua field wajib diisi." });
    }

    const [existing] = await db.query(
      "SELECT id FROM mahasiswa WHERE nim = ?",
      [nim]
    );
    if (existing.length > 0) {
      return res.status(400).json({ message: "NIM sudah terdaftar." });
    }

    const [existingUser] = await db.query(
      "SELECT id, role FROM users WHERE username = ?",
      [email]
    );

    let userId;

    if (existingUser.length > 0) {
      const found = existingUser[0];

      if (found.role !== "mahasiswa") {
        return res.status(400).json({
          message: `Email/username ini sudah terdaftar sebagai akun ${found.role}. Gunakan email lain untuk mahasiswa ini.`,
        });
      }

      const [mhsLain] = await db.query(
        "SELECT nim, nama FROM mahasiswa WHERE user_id = ?",
        [found.id]
      );
      if (mhsLain.length > 0 && mhsLain[0].nim !== nim) {
        return res.status(400).json({
          message: `Email ini sudah terdaftar untuk mahasiswa lain (${mhsLain[0].nama} - NIM ${mhsLain[0].nim}). Gunakan email lain.`,
        });
      }

      userId = found.id;
    } else {
      const hashedPassword = await bcrypt.hash(nim, 8);
      userId = uuidv4();
      await db.query(
        "INSERT INTO users (id, username, password, role) VALUES (?, ?, ?, ?)",
        [userId, email, hashedPassword, "mahasiswa"]
      );
    }

    const mahasiswaId = uuidv4();

    await db.query(
      "INSERT INTO mahasiswa (id, user_id, nim, nama, email, program_studi, imported_by) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [mahasiswaId, userId, nim, nama, email || null, program_studi, req.user.id]
    );

    await db.query(
      "INSERT INTO pengajuan (id, mahasiswa_id, periode_id, status) VALUES (?, ?, ?, 'draft')",
      [uuidv4(), mahasiswaId, periode_id]
    );

    res.status(201).json({ message: "Mahasiswa berhasil ditambahkan." });
  } catch (error) {
    console.error("Tambah mahasiswa error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ========== IMPORT DOSEN ==========

const importDosen = async (req, res) => {
  try {
    if (!req.file)
      return res.status(400).json({ message: 'File tidak ditemukan.' });

    const workbook = xlsx.readFile(req.file.path);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const data = xlsx.utils.sheet_to_json(sheet);

    if (data.length === 0)
      return res.status(400).json({ message: 'File kosong atau format tidak sesuai.' });

    let berhasil = 0, gagal = 0, errors = [];

    for (const row of data) {
      try {
        const id_dosen      = String(row['ID Dosen'] || row['id_dosen'] || row['Id Dosen'] || '').trim();
        const nama          = String(row['Nama']     || row['nama']     || row['NAMA']     || '').trim();
        const email         = String(row['Email']    || row['email']    || '').trim();
        const program_studi = String(row['Program Studi'] || row['program_studi'] || '').trim() || null;

        if (!id_dosen || !nama) {
          gagal++;
          errors.push(`Baris dilewati: ID Dosen atau Nama kosong`);
          continue;
        }

        const [existing] = await db.query('SELECT id FROM dosen WHERE id_dosen = ?', [id_dosen]);
        if (existing.length > 0) {
          gagal++;
          errors.push(`ID Dosen ${id_dosen} sudah terdaftar, dilewati.`);
          continue;
        }

        const hashedPassword = await bcrypt.hash(id_dosen, 10);
        const userId = uuidv4();

        await db.query(
          'INSERT INTO users (id, username, password, role) VALUES (?, ?, ?, ?)',
          [userId, email || id_dosen, hashedPassword, 'dosen_pembimbing']
        );

        await db.query(
          'INSERT INTO dosen (id, user_id, id_dosen, nama, email, program_studi) VALUES (?, ?, ?, ?, ?, ?)',
          [uuidv4(), userId, id_dosen, nama, email || null, program_studi]
        );

        berhasil++;
      } catch (rowError) {
        gagal++;
        errors.push(`Error: ${rowError.message}`);
      }
    }

    fs.unlinkSync(req.file.path);
    res.json({
      message: `Import selesai. Berhasil: ${berhasil}, Gagal: ${gagal}`,
      berhasil, gagal, errors,
    });
  } catch (error) {
    console.error('Import dosen error:', error);
    res.status(500).json({ message: 'Terjadi kesalahan server.' });
  }
};

// ========== TAMBAH DOSEN ==========

const tambahDosen = async (req, res) => {
  try {
    const { id_dosen, nama, email, program_studi } = req.body;

    if (!id_dosen || !nama || !email || !program_studi) {
      return res.status(400).json({ message: "Semua field wajib diisi." });
    }

    const [existing] = await db.query("SELECT id FROM dosen WHERE id_dosen = ?", [id_dosen]);
    if (existing.length > 0) {
      return res.status(400).json({ message: "ID Dosen sudah terdaftar." });
    }

    const hashedPassword = await bcrypt.hash(id_dosen, 10);
    const userId = uuidv4();

    await db.query(
      'INSERT INTO users (id, username, password, role) VALUES (?, ?, ?, ?)',
      [userId, email, hashedPassword, 'dosen_pembimbing']
    );

    await db.query(
      'INSERT INTO dosen (id, user_id, id_dosen, nama, email, program_studi) VALUES (?, ?, ?, ?, ?, ?)',
      [uuidv4(), userId, id_dosen, nama, email, program_studi]
    );

    res.status(201).json({ message: "Dosen berhasil ditambahkan." });
  } catch (error) {
    console.error("Tambah dosen error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ========== UPDATE DOSEN ==========
// PERUBAHAN: update ke `users` sekarang cuma `username` + `is_active` (nama/email
// disimpan & diupdate di tabel `dosen` saja).

const updateDosen = async (req, res) => {
  try {
    const { id } = req.params;
    const { id_dosen, nama, email, program_studi, is_active } = req.body;

    if (!id_dosen || !nama || !email || !program_studi) {
      return res.status(400).json({ message: "Semua field wajib diisi." });
    }

    const [dosen] = await db.query("SELECT * FROM dosen WHERE id = ?", [id]);
    if (!dosen.length) {
      return res.status(404).json({ message: "Dosen tidak ditemukan." });
    }

    await db.query(
      "UPDATE dosen SET id_dosen=?, nama=?, email=?, program_studi=? WHERE id=?",
      [id_dosen, nama, email, program_studi, id]
    );

    await db.query(
      "UPDATE users SET username=?, is_active=? WHERE id=?",
      [id_dosen, is_active ? 1 : 0, dosen[0].user_id]
    );

    res.json({ message: "Data dosen berhasil diperbarui." });
  } catch (error) {
    console.error("Update dosen error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ========== UPDATE MAHASISWA ==========

const updateMahasiswa = async (req, res) => {
  try {
    const { id } = req.params;
    const { nim, nama, email, program_studi } = req.body;

    if (!nim || !nama || !email || !program_studi) {
      return res.status(400).json({ message: "Semua field wajib diisi." });
    }

    const [mhs] = await db.query("SELECT * FROM mahasiswa WHERE id = ?", [id]);
    if (!mhs.length) {
      return res.status(404).json({ message: "Mahasiswa tidak ditemukan." });
    }

    // cek NIM bentrok dengan mahasiswa lain di periode yang sama
    const [nimBentrok] = await db.query(
    "SELECT id FROM mahasiswa WHERE nim = ? AND id != ?",
    [nim, id]
);
    if (nimBentrok.length > 0) {
      return res.status(400).json({ message: "NIM sudah digunakan mahasiswa lain di periode ini." });
    }

    await db.query(
      "UPDATE mahasiswa SET nim=?, nama=?, email=?, program_studi=? WHERE id=?",
      [nim, nama, email, program_studi, id]
    );

    await db.query(
      "UPDATE users SET username=? WHERE id=?",
      [email || nim, mhs[0].user_id]
    );

    res.json({ message: "Data mahasiswa berhasil diperbarui." });
  } catch (error) {
    console.error("Update mahasiswa error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ========== HAPUS MAHASISWA ==========
// PERUBAHAN BESAR: dulu manual DELETE ke dokumen/logbook/bimbingan by mahasiswa_id
// (kolom itu sekarang gak ada lagi di tabel-tabel itu). Sekarang cukup hapus
// `pengajuan` -> ON DELETE CASCADE otomatis membereskan detail_pengajuan,
// logbook, dokumen, bimbingan, feedback, penilaian (dikonfirmasi dari
// mahasiswaController.hapusPengajuan).

const hapusMahasiswa = async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { id } = req.params;

    const [mhs] = await conn.query("SELECT * FROM mahasiswa WHERE id = ?", [id]);
    if (!mhs.length) {
      conn.release();
      return res.status(404).json({ message: "Mahasiswa tidak ditemukan." });
    }

    await conn.beginTransaction();

    await conn.query("DELETE FROM notifikasi WHERE user_id = ?", [mhs[0].user_id]);
    // Cascade dari pengajuan membereskan detail_pengajuan, logbook, dokumen,
    // bimbingan, feedback, penilaian yang menempel ke pengajuan_id mahasiswa ini.
    await conn.query("DELETE FROM pengajuan WHERE mahasiswa_id = ?", [id]);
    await conn.query("DELETE FROM mahasiswa WHERE id = ?", [id]);

    // Cuma hapus users kalau ini satu-satunya baris mahasiswa yang pakai user_id ini
    // (mahasiswa yang reapply di periode lain berbagi user_id yang sama).
    const [sisaMahasiswa] = await conn.query(
      "SELECT id FROM mahasiswa WHERE user_id = ?",
      [mhs[0].user_id]
    );
    if (sisaMahasiswa.length === 0) {
      await conn.query("DELETE FROM users WHERE id = ?", [mhs[0].user_id]);
    }

    await conn.commit();
    res.json({ message: "Mahasiswa berhasil dihapus." });
  } catch (error) {
    await conn.rollback();
    console.error("hapusMahasiswa error:", error);
    res.status(500).json({ message: "Gagal menghapus mahasiswa.", detail: error.message });
  } finally {
    conn.release();
  }
};

// ========== RESET PASSWORD MAHASISWA ==========

const resetPasswordMahasiswa = async (req, res) => {
  try {
    const { id } = req.params;

    const [mhs] = await db.query("SELECT * FROM mahasiswa WHERE id = ?", [id]);
    if (!mhs.length) {
      return res.status(404).json({ message: "Mahasiswa tidak ditemukan." });
    }

    const hashedPassword = await bcrypt.hash(mhs[0].nim, 8);

    await db.query("UPDATE users SET password = ? WHERE id = ?", [
      hashedPassword, mhs[0].user_id,
    ]);

    await db.query(
      "INSERT INTO notifikasi (id, user_id, judul, pesan, tipe) VALUES (?, ?, ?, ?, ?)",
      [
        uuidv4(), mhs[0].user_id,
        "Password Direset",
        "Password akun kamu telah direset oleh Kaprodi. Password baru kamu adalah NIM kamu.",
        "peringatan",
      ]
    );

    res.json({
      message: "Password mahasiswa berhasil direset.",
      info: `Password baru: ${mhs[0].nim}`,
    });
  } catch (error) {
    console.error("resetPasswordMahasiswa error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ========== MONITORING ==========

const getDaftarMahasiswa = async (req, res) => {
  try {
    const { periode_id } = req.query;

    let query = `
      SELECT
        m.*,
        u.is_active,
        p.id AS pengajuan_id,
        p.status AS status_pengajuan,
        p.periode_id,
        dp.judul AS judul_capstone,
        b.dosen_id,
        d.nama AS nama_dosen
      FROM mahasiswa m
      LEFT JOIN users u
        ON u.id = m.user_id
      LEFT JOIN pengajuan p
        ON p.mahasiswa_id = m.id
      LEFT JOIN detail_pengajuan dp
        ON dp.pengajuan_id = p.id
      LEFT JOIN bimbingan b
        ON b.pengajuan_id = p.id
      LEFT JOIN dosen d
        ON d.id = b.dosen_id
    `;

    const params = [];

    if (periode_id) {
      query += ` WHERE p.periode_id = ?`;
      params.push(periode_id);
    }

    query += ` ORDER BY m.nama ASC`;

    const [rows] = await db.query(query, params);

    res.json({ data: rows });
  } catch (error) {
    console.error("getDaftarMahasiswa error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

const getDaftarDosen = async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT d.*, u.is_active
      FROM dosen d LEFT JOIN users u ON d.user_id = u.id
      ORDER BY d.nama ASC
    `);
    res.json({ data: rows });
  } catch (error) {
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ─────────────────────────────────────────
// GET /staff/dashboard-stats
// PERUBAHAN: pengajuan_capstone (sudah di-drop) -> pengajuan
// ─────────────────────────────────────────
const getDashboardStats = async (req, res) => {
  try {
    const [[{ total }]] = await db.query(
      "SELECT COUNT(*) as total FROM pengajuan"
    );
    res.json({ data: { total_pengajuan: total } });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ─────────────────────────────────────────
// GET /staff/aktivitas-terbaru
// PERUBAHAN: pengajuan_capstone -> pengajuan + join detail_pengajuan buat judul.
// dokumen di-join lewat pengajuan_id (bukan mahasiswa_id langsung, kolom itu
// sudah tidak ada lagi di tabel dokumen).
// ─────────────────────────────────────────
const getAktivitasTerbaru = async (req, res) => {
  try {
    const [pengajuan] = await db.query(`
      SELECT 'pengajuan' as tipe, p.id, m.nama as nama_mahasiswa, m.nim,
        p.created_at, p.status, dp.judul as deskripsi
      FROM pengajuan p
      JOIN mahasiswa m ON p.mahasiswa_id = m.id
      LEFT JOIN detail_pengajuan dp ON dp.pengajuan_id = p.id
      ORDER BY p.created_at DESC LIMIT 5
    `);

    const [dokumen] = await db.query(`
      SELECT 'dokumen' as tipe, d.id, m.nama as nama_mahasiswa, m.nim,
        d.created_at, d.status, d.nama_file as deskripsi
      FROM dokumen d
      JOIN pengajuan p ON d.pengajuan_id = p.id
      JOIN mahasiswa m ON p.mahasiswa_id = m.id
      ORDER BY d.created_at DESC LIMIT 5
    `);

    const aktivitas = [...pengajuan, ...dokumen]
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 10);

    res.json({ data: aktivitas });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ─────────────────────────────────────────
// GET /staff/pengajuan
// PERUBAHAN: pengajuan_capstone -> pengajuan + detail_pengajuan.
// bimbingan join lewat pengajuan_id (bukan mahasiswa_id+periode_id).
// ─────────────────────────────────────────
const getDaftarPengajuan = async (req, res) => {
  try {
    const { periode_id, status, search } = req.query;

    let where = "WHERE 1=1";
    const params = [];

    if (periode_id) { where += " AND p.periode_id = ?"; params.push(periode_id); }
    if (status)     { where += " AND p.status = ?";     params.push(status); }
    if (search) {
      where += " AND (m.nama LIKE ? OR m.nim LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }

    const [rows] = await db.query(`
      SELECT
        p.id, dp.judul, p.status, p.created_at, p.periode_id,
        m.id as mahasiswa_id, m.nim, m.nama, m.program_studi,
        per.nama_periode,
        d.nama as nama_dosen
      FROM pengajuan p
      JOIN mahasiswa m ON p.mahasiswa_id = m.id
      JOIN periode per ON p.periode_id = per.id
      LEFT JOIN detail_pengajuan dp ON dp.pengajuan_id = p.id
      LEFT JOIN bimbingan b ON b.pengajuan_id = p.id
      LEFT JOIN dosen d ON b.dosen_id = d.id
      ${where}
      ORDER BY p.created_at DESC
    `, params);

    res.json({ data: rows });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ─────────────────────────────────────────
// GET /staff/pengajuan/:id
// PERUBAHAN: field pelatihan/judul/deskripsi/lokasi/tanggal_* sekarang ada di
// detail_pengajuan, bukan langsung di pengajuan. bimbingan join lewat pengajuan_id.
// ─────────────────────────────────────────
const getDetailPengajuan = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await db.query(`
      SELECT
        p.id, p.mahasiswa_id, p.periode_id,
        dp.pelatihan, dp.judul, dp.deskripsi, dp.lokasi,
        dp.tanggal_mulai, dp.tanggal_selesai,
        p.status, p.catatan_dosen, p.catatan_kaprodi,
        p.created_at, p.archived_at,
        m.nim, m.nama, m.program_studi, m.email,
        per.nama_periode,
        d.nama as nama_dosen
      FROM pengajuan p
      JOIN mahasiswa m ON p.mahasiswa_id = m.id
      JOIN periode per ON p.periode_id = per.id
      LEFT JOIN detail_pengajuan dp ON dp.pengajuan_id = p.id
      LEFT JOIN bimbingan b ON b.pengajuan_id = p.id
      LEFT JOIN dosen d ON b.dosen_id = d.id
      WHERE p.id = ?
    `, [id]);

    if (!rows.length) return res.status(404).json({ message: "Pengajuan tidak ditemukan." });
    const pengajuan = rows[0];

    // Parse kolom pelatihan (JSON array of object)
    let pelatihan = [];
    try {
      const raw = pengajuan.pelatihan;
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          pelatihan = parsed.map(item => ({
            nama_pelatihan: typeof item === 'string'
              ? item
              : (item.nama || item.nama_pelatihan || item.judul || String(item)),
            status: item.status || pengajuan.status,
          }));
        } else if (typeof parsed === 'string') {
          pelatihan = [{ nama_pelatihan: parsed, status: pengajuan.status }];
        }
      }
    } catch {
      // Bukan JSON, perlakukan sebagai plain string
      if (pengajuan.pelatihan) {
        pelatihan = [{ nama_pelatihan: pengajuan.pelatihan, status: pengajuan.status }];
      }
    }

    res.json({
      data: {
        ...pengajuan,
        pelatihan,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ─────────────────────────────────────────
// POST /staff/pengajuan/:id/arsipkan
// PERUBAHAN: pengajuan_capstone -> pengajuan. Tambah `id` (uuidv4) di INSERT
// notifikasi, konsisten dengan semua controller lain (aslinya hilang di versi lama).
// ─────────────────────────────────────────
const arsipkanPengajuan = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await db.query(
      "SELECT p.*, m.user_id FROM pengajuan p JOIN mahasiswa m ON p.mahasiswa_id = m.id WHERE p.id = ?",
      [id]
    );
    if (!rows.length) return res.status(404).json({ message: "Pengajuan tidak ditemukan." });
    const pengajuan = rows[0];
    if (pengajuan.status === 'diarsipkan')
      return res.status(400).json({ message: "Pengajuan sudah diarsipkan." });

    await db.query(
      "UPDATE pengajuan SET status = 'diarsipkan', archived_at = NOW(), archived_by = ? WHERE id = ?",
      [req.user.id, id]
    );
    await db.query(
      "INSERT INTO notifikasi (id, user_id, judul, pesan, tipe) VALUES (?, ?, ?, ?, ?)",
      [uuidv4(), pengajuan.user_id, "Data Diarsipkan",
        "Data Capstone Project kamu telah diarsipkan oleh Staff Akademik.", "sukses"]
    );
    res.json({ message: "Pengajuan berhasil diarsipkan." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ─────────────────────────────────────────
// Helper: ambil data pengajuan + pelatihan untuk export
// PERUBAHAN: pengajuan_capstone -> pengajuan + detail_pengajuan.
// bimbingan join lewat pengajuan_id.
// ─────────────────────────────────────────
const _getExportRows = async (periode_id, mahasiswa_id) => {
  let where = "WHERE 1=1";
  const params = [];
  if (periode_id)   { where += " AND p.periode_id = ?"; params.push(periode_id); }
  if (mahasiswa_id) { where += " AND m.id = ?";          params.push(mahasiswa_id); }

  const [rows] = await db.query(`
    SELECT
      m.id as mahasiswa_id,
      m.nim, m.nama, m.program_studi,
      p.id as pengajuan_id,
      dp.pelatihan, dp.judul,
      per.nama_periode, p.status,
      d.nama as nama_dosen
    FROM pengajuan p
    JOIN mahasiswa m ON p.mahasiswa_id = m.id
    JOIN periode per ON p.periode_id = per.id
    LEFT JOIN detail_pengajuan dp ON dp.pengajuan_id = p.id
    LEFT JOIN bimbingan b ON b.pengajuan_id = p.id
    LEFT JOIN dosen d ON b.dosen_id = d.id
    ${where}
    ORDER BY m.nama ASC
  `, params);

  for (const r of rows) {
    let pelatihan = [];
    try {
      const raw = r.pelatihan;
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          pelatihan = parsed.map(item => ({
            nama_pelatihan: typeof item === 'string'
              ? item
              : (item.nama || item.nama_pelatihan || item.judul || String(item)),
            status: item.status || r.status,
          }));
        } else if (typeof parsed === 'string') {
          pelatihan = [{ nama_pelatihan: parsed, status: r.status }];
        }
      }
    } catch {
      if (r.pelatihan) {
        pelatihan = [{ nama_pelatihan: r.pelatihan, status: r.status }];
      }
    }

    r.daftar_pelatihan = pelatihan.length > 0
      ? pelatihan
      : [{ nama_pelatihan: '-', status: r.status }];
  }

  return rows;
};

// ─────────────────────────────────────────
// Helper: label status
// ─────────────────────────────────────────
const _statusLabel = (s) => ({
  disetujui_kaprodi: 'Disetujui',
  ditolak:           'Ditolak',
  diajukan:          'Diajukan',
  revisi:            'Revisi',
  diarsipkan:        'Diarsipkan',
}[s] || s || '-');

// ─────────────────────────────────────────
// GET /staff/pengajuan/export-excel
// (Tidak ada perubahan logic styling/Excel di bawah ini -- cuma bergantung ke
// _getExportRows yang sudah diperbaiki di atas.)
// ─────────────────────────────────────────
const exportPengajuanExcel = async (req, res) => {
  try {
    const { periode_id, mahasiswa_id } = req.query;
    const rows = await _getExportRows(periode_id, mahasiswa_id);

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Data Pengajuan MBKM");

    sheet.getColumn(1).width = 5;
    sheet.getColumn(2).width = 14;
    sheet.getColumn(3).width = 25;
    sheet.getColumn(4).width = 25;
    sheet.getColumn(5).width = 25;
    sheet.getColumn(6).width = 35;
    sheet.getColumn(7).width = 15;
    sheet.getColumn(8).width = 18;

    const headerRow = sheet.addRow([
      "No", "NIM", "Nama", "Program Studi", "Dosen Pembimbing",
      "Judul Pelatihan", "Status", "Periode"
    ]);

    headerRow.height = 25;

    headerRow.eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 9 };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2563EB' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      cell.border = {
        top: { style: 'medium', color: { argb: 'FF1D4ED8' } },
        bottom: { style: 'medium', color: { argb: 'FF1D4ED8' } },
        left: { style: 'thin', color: { argb: 'FF1D4ED8' } },
        right: { style: 'thin', color: { argb: 'FF1D4ED8' } },
      };
    });

    const cellBorder = {
      top: { style: 'thin', color: { argb: 'FFE2E8F0' } },
      bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } },
      left: { style: 'thin', color: { argb: 'FFD1D5DB' } },
      right: { style: 'thin', color: { argb: 'FFD1D5DB' } },
    };

    const charsPerRow = { nama: 25, prodi: 25, dosen: 25, judul: 40 };

    const estimateLines = (text, chars) =>
      Math.max(1, Math.ceil(String(text || '-').length / chars));

    let excelRowIndex = 1;

    rows.forEach((r, i) => {
      const pelatihanList = r.daftar_pelatihan;
      const bgArgb = i % 2 === 0 ? 'FFFFFFFF' : 'FFF8FAFF';
      const startRow = excelRowIndex + 1;
      const ROW_H_BASE = 18;

      pelatihanList.forEach((pt, ptIdx) => {
        const namaLines = estimateLines(r.nama, charsPerRow.nama);
        const prodiLines = estimateLines(r.program_studi, charsPerRow.prodi);
        const dosenLines = estimateLines(r.nama_dosen, charsPerRow.dosen);
        const judulLines = estimateLines(pt.nama_pelatihan, charsPerRow.judul);

        const rowH = Math.max(
          ROW_H_BASE,
          namaLines * ROW_H_BASE,
          prodiLines * ROW_H_BASE,
          dosenLines * ROW_H_BASE,
          judulLines * ROW_H_BASE
        );

        const exRow = sheet.addRow([
          ptIdx === 0 ? i + 1 : null,
          ptIdx === 0 ? r.nim : null,
          ptIdx === 0 ? r.nama : null,
          ptIdx === 0 ? (r.program_studi || '-') : null,
          ptIdx === 0 ? (r.nama_dosen || '-') : null,
          pt.nama_pelatihan || '-',
          _statusLabel(pt.status),
          ptIdx === 0 ? r.nama_periode : null,
        ]);

        exRow.height = rowH;

        exRow.eachCell({ includeEmpty: true }, (cell, colNum) => {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgArgb } };
          cell.border = cellBorder;
          cell.font = { size: 9, color: { argb: 'FF111827' } };
          cell.alignment = {
            vertical: 'middle',
            horizontal: colNum === 1 ? 'center' : 'left',
            wrapText: true
          };

          if (colNum === 7) {
            const statusColor =
              pt.status === 'disetujui_kaprodi' ? 'FF16a34a' :
              pt.status === 'ditolak' ? 'FFdc2626' :
              pt.status === 'diarsipkan' ? 'FF2563eb' :
              pt.status === 'revisi' ? 'FFd97706' :
              'FF6b7280';

            cell.font = { size: 9, bold: true, color: { argb: statusColor } };
          }
        });

        excelRowIndex++;
      });

      const endRow = excelRowIndex;

      if (pelatihanList.length > 1) {
        [1, 2, 3, 4, 5, 8].forEach(col => {
          sheet.mergeCells(startRow, col, endRow, col);
          const cell = sheet.getCell(startRow, col);
          cell.alignment = {
            vertical: 'middle',
            horizontal: col === 1 ? 'center' : 'left',
            wrapText: true
          };
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgArgb } };
          cell.border = cellBorder;
          cell.font = { size: 9, color: { argb: 'FF111827' } };
        });
      }

      const lastRow = sheet.getRow(endRow);
      lastRow.eachCell({ includeEmpty: true }, cell => {
        cell.border = {
          ...cellBorder,
          bottom: { style: 'thin', color: { argb: 'FFCBD5E1' } },
        };
      });
    });

    sheet.views = [{ state: 'frozen', ySplit: 1 }];

    sheet.eachRow(row => {
      row.eachCell(cell => {
        cell.alignment = { ...cell.alignment, vertical: 'middle', wrapText: true };
      });
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=pengajuan_mbkm.xlsx');

    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ─────────────────────────────────────────
// GET /staff/pengajuan/export-pdf
// (Tidak ada perubahan logic layout PDF -- cuma bergantung ke _getExportRows
// yang sudah diperbaiki di atas.)
// ─────────────────────────────────────────
const exportPengajuanPDF = async (req, res) => {
  try {
    const { periode_id, mahasiswa_id } = req.query;
    const rows = await _getExportRows(periode_id, mahasiswa_id);

    const isSingle = !!mahasiswa_id && rows.length === 1;

    const doc = new PDFDocument({ margin: 50, size: 'A4' });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=${
        isSingle ? `detail_${rows[0]?.nim || 'mahasiswa'}.pdf` : 'rekap_pengajuan_mbkm.pdf'
      }`
    );

    doc.pipe(res);

    doc.fontSize(14).font('Helvetica-Bold').text('REKAP DATA PENGAJUAN MBKM', { align: 'center' });
    doc.fontSize(10).font('Helvetica')
      .text('Program Studi Sistem dan Teknologi Informasi', { align: 'center' })
      .text('Institut Teknologi & Bisnis Sabda Setia', { align: 'center' });

    if (rows.length) {
      doc.text(`Periode: ${rows[0].nama_periode}`, { align: 'center' });
    }

    doc.moveDown(1);
    doc.moveTo(50, doc.y).lineTo(545, doc.y).lineWidth(1).stroke('#94a3b8');
    doc.moveDown(1);

    if (isSingle) {
      const r = rows[0];

      const field = (label, value) => {
        const y = doc.y;
        doc.font('Helvetica-Bold').fontSize(9).text(label, 50, y, { width: 155 });
        doc.font('Helvetica').fontSize(9).text(': ' + String(value || '-'), 205, y, { width: 330 });
        doc.moveDown(0.5);
      };

      doc.font('Helvetica-Bold').fontSize(10).fillColor('#1e3a8a').text('Informasi Mahasiswa');
      doc.fillColor('black');
      doc.moveDown(0.5);

      field('NIM', r.nim);
      field('Nama', r.nama);
      field('Program Studi', r.program_studi);
      field('Dosen Pembimbing', r.nama_dosen || '-');
      field('Periode', r.nama_periode);

      const pelatihanList = r.daftar_pelatihan;
      const PELATIHAN_NO_X = 205;
      const showNumbering = pelatihanList.length > 1;

      {
        const y = doc.y;
        doc.font('Helvetica-Bold').fontSize(9).text('Judul Pelatihan', 50, y, { width: 155 });
        doc.font('Helvetica').fontSize(9).text(':', PELATIHAN_NO_X, y, { width: 12 });
        doc.text(
          showNumbering
            ? `1. ${pelatihanList[0]?.nama_pelatihan || '-'}`
            : (pelatihanList[0]?.nama_pelatihan || '-'),
          PELATIHAN_NO_X + 12, y, { width: 330 - 12 }
        );
        doc.moveDown(0.4);
      }

      pelatihanList.slice(1).forEach((pt, index) => {
        doc.font('Helvetica').fontSize(9).text(
          `${index + 2}. ${pt.nama_pelatihan}`,
          PELATIHAN_NO_X + 12, doc.y, { width: 330 - 12 }
        );
        doc.moveDown(0.4);
      });
    } else {
      const COL = { no: 50, nim: 70, nama: 130, dosen: 230, judul: 335, status: 490 };
      const WID = { no: 20, nim: 60, nama: 95, dosen: 100, judul: 145, status: 55 };
      const FONT_SIZE = 8;
      const LINE_H = 13;
      const ROW_PAD = 6;

      const textHeight = (text, width) => {
        const chars = Math.floor(width / (FONT_SIZE * 0.52));
        const lines = Math.ceil(String(text || '-').length / chars);
        return Math.max(1, lines) * LINE_H;
      };

      const drawHeader = () => {
        const y = doc.y;
        doc.rect(50, y, 495, 22).fill('#2563EB');
        doc.fillColor('white').font('Helvetica-Bold').fontSize(FONT_SIZE);

        doc.text('No', COL.no, y + 6, { width: WID.no });
        doc.text('NIM', COL.nim, y + 6, { width: WID.nim });
        doc.text('Nama', COL.nama, y + 6, { width: WID.nama });
        doc.text('Dosen Pembimbing', COL.dosen, y + 6, { width: WID.dosen });
        doc.text('Judul Pelatihan', COL.judul, y + 6, { width: WID.judul });
        doc.text('Status', COL.status, y + 6, { width: WID.status });

        doc.fillColor('black');
        doc.y = y + 22;
      };

      drawHeader();

      rows.forEach((r, i) => {
        const list = r.daftar_pelatihan;
        const heights = list.map(pt =>
          Math.max(LINE_H, textHeight(pt.nama_pelatihan, WID.judul))
        );
        const totalH = heights.reduce((a, b) => a + b, 0) + ROW_PAD * 2;

        if (doc.y + totalH > 760) {
          doc.addPage();
          drawHeader();
        }

        const y = doc.y;
        const bg = i % 2 === 0 ? '#ffffff' : '#f0f6ff';

        doc.rect(50, y, 495, totalH).fill(bg);
        doc.fillColor('#111827').font('Helvetica').fontSize(FONT_SIZE);

        const centerY = y + (totalH - LINE_H) / 2;

        doc.text(`${i + 1}`, COL.no, centerY, { width: WID.no });
        doc.text(r.nim, COL.nim, centerY, { width: WID.nim });
        doc.text(r.nama, COL.nama, centerY, { width: WID.nama });
        doc.text(r.nama_dosen || '-', COL.dosen, centerY, { width: WID.dosen });

        let ptY = y + ROW_PAD;

        list.forEach((pt, index) => {
          doc.text(pt.nama_pelatihan || '-', COL.judul, ptY, { width: WID.judul });

          doc.font('Helvetica-Bold').fillColor('#16a34a').text(
            _statusLabel(pt.status), COL.status, ptY, { width: WID.status }
          );

          doc.fillColor('#111827').font('Helvetica');
          ptY += heights[index];

          if (index < list.length - 1) {
            doc.moveTo(COL.judul, ptY).lineTo(545, ptY).lineWidth(0.4).stroke('#cbd5e1');
          }
        });

        const bottom = y + totalH;
        doc.moveTo(50, bottom).lineTo(545, bottom).lineWidth(1).stroke('#64748b');
        doc.y = bottom + 1;
      });

      doc.moveTo(50, doc.y).lineTo(545, doc.y).lineWidth(1.5).stroke('#334155');
    }

    doc.end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ─────────────────────────────────────────
// GET /staff/profil
// PERUBAHAN BESAR: `users` sudah tidak punya kolom `nama`/`email` -- data itu
// sekarang ada di tabel `staff_akademik` (id, user_id, nama, email,
// created_at, updated_at) -- terkonfirmasi dari staff_akademik.sql.
// ─────────────────────────────────────────
const getProfil = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT u.id, u.username, u.role, u.created_at,
              s.nama, s.email
       FROM users u
       LEFT JOIN staff_akademik s ON s.user_id = u.id
       WHERE u.id = ?`,
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ message: "User tidak ditemukan." });
    res.json({ data: rows[0] });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

const updateProfil = async (req, res) => {
  try {
    const { nama, email } = req.body;
    await db.query(
      "UPDATE staff_akademik SET nama = ?, email = ? WHERE user_id = ?",
      [nama, email, req.user.id]
    );
    res.json({ message: "Profil berhasil diperbarui." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

const getPeriode = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT id, nama_periode FROM periode ORDER BY id DESC');
    res.json({ data: rows });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Terjadi kesalahan server.' });
  }
};

// ─────────────────────────────────────────
// GET /staff/rekap-nilai
// Cuma nilai yang sudah difinalisasi dosen (finalized_at IS NOT NULL) yang
// boleh tampil ke Staff -- sebelum final, nilai masih draft dan cuma dosen
// pembimbing yang boleh lihat/ubah.
// ─────────────────────────────────────────
const getRekapNilai = async (req, res) => {
  try {
    const { periode_id } = req.query;
    const params = [];
    let where = "WHERE pn.finalized_at IS NOT NULL";
    if (periode_id) {
      where += " AND p.periode_id = ?";
      params.push(periode_id);
    }

    const [rows] = await db.query(
      `SELECT
        pn.id, pn.pengajuan_id, pn.finalized_at,
        pn.nilai_kesesuaian, pn.nilai_proyek, pn.nilai_evaluasi,
        pn.nilai_laporan, pn.nilai_presentasi, pn.nilai_akhir, pn.grade, pn.catatan,
        m.nim, m.nama, m.program_studi,
        per.nama_periode,
        d.nama as nama_dosen
      FROM penilaian pn
      JOIN pengajuan p ON p.id = pn.pengajuan_id
      JOIN mahasiswa m ON p.mahasiswa_id = m.id
      JOIN periode per ON p.periode_id = per.id
      LEFT JOIN dosen d ON d.id = pn.dosen_id
      ${where}
      ORDER BY m.nama ASC`,
      params
    );

    res.json({ data: rows });
  } catch (error) {
    console.error("getRekapNilai error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

// ========== MENU LOGBOOK & DOKUMEN (BARU, VIEW-ONLY) ==========
// Staff tidak boleh verifikasi/reject/feedback/ubah status -- hanya lihat.
// Pola query mirip dosenController.getMahasiswaBimbingan/getLogbookMahasiswa/
// getDokumenMahasiswa, tapi tanpa filter bimbingan.dosen_id (Staff lihat semua).

const getDaftarMahasiswaMBKM = async (req, res) => {
  try {
    const { periode_id } = req.query;
    const [rows] = await db.query(
      `SELECT
        m.nim, m.nama,
        p.id as pengajuan_id, p.status as status_pengajuan,
        dp.judul as program_mbkm, dp.penyelenggara as instansi,
        COUNT(DISTINCT l.id) as jumlah_logbook
      FROM mahasiswa m
      INNER JOIN pengajuan p ON p.mahasiswa_id = m.id ${periode_id ? "AND p.periode_id = ?" : ""}
      LEFT JOIN detail_pengajuan dp ON dp.pengajuan_id = p.id
      LEFT JOIN logbook l ON l.pengajuan_id = p.id
      GROUP BY m.id, m.nim, m.nama, p.id, p.status, dp.judul, dp.penyelenggara
      ORDER BY m.nama ASC`,
      periode_id ? [periode_id] : []
    );
    res.json({ data: rows });
  } catch (error) {
    console.error("getDaftarMahasiswaMBKM error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

const getLogbookMahasiswa = async (req, res) => {
  try {
    const { pengajuan_id } = req.query;
    if (!pengajuan_id) return res.status(400).json({ message: "pengajuan_id wajib diisi." });

   const [rows] = await db.query(
  `SELECT id, tanggal, jam_mulai, jam_selesai, kegiatan, durasi_menit, status, bukti_path, bukti_link
   FROM logbook WHERE pengajuan_id = ? ORDER BY tanggal DESC`,
  [pengajuan_id]
);
    res.json({ data: rows });
  } catch (error) {
    console.error("getLogbookMahasiswa (staff) error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

const getDokumenMahasiswa = async (req, res) => {
  try {
    const { pengajuan_id } = req.query;
    if (!pengajuan_id) return res.status(400).json({ message: "pengajuan_id wajib diisi." });

    const [rows] = await db.query(
      `SELECT id, jenis, nama_file, cloudinary_url, status FROM dokumen WHERE pengajuan_id = ?`,
      [pengajuan_id]
    );
    res.json({ data: rows });
  } catch (error) {
    console.error("getDokumenMahasiswa (staff) error:", error);
    res.status(500).json({ message: "Terjadi kesalahan server." });
  }
};

module.exports = {
  // Dipindah dari kaprodiController.js (item #6)
  importMahasiswa, tambahMahasiswa,
  importDosen, tambahDosen, updateDosen,
  updateMahasiswa, hapusMahasiswa, resetPasswordMahasiswa,
  getDaftarMahasiswa, getDaftarDosen,
  // Existing
  getDashboardStats,
  getAktivitasTerbaru,
  getDaftarPengajuan,
  getDetailPengajuan,
  arsipkanPengajuan,
  exportPengajuanExcel,
  exportPengajuanPDF,
  getProfil,
  updateProfil,
  getPeriode,
  getRekapNilai,
  // BARU: menu Logbook & Dokumen (view-only, item permintaan baru)
  getDaftarMahasiswaMBKM,
  getLogbookMahasiswa,
  getDokumenMahasiswa,
};